# NEXUS 1.0

Protótipo funcional de um sistema operacional empresarial com Dashboard, NEXUS IA, Empresa, CRM, Financeiro, Operação, Marketing, Mercado, Configurações e uma área demonstrativa de Porsche 911.

## Como abrir
Abra `index.html` em um navegador moderno. Não há dependências externas.

## Observação
Esta versão é um MVP front-end. Dados são demonstrativos e ficam em memória durante a sessão. Para produção, conectar autenticação, banco de dados, IA real, APIs de mercado, pagamentos e permissões multiusuário.
